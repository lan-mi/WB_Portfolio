/* Copyright year */

$('#date').html(new Date().getFullYear());

